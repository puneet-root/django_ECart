from django.shortcuts import redirect
def login_auth_middleware(get_response):
    # One-time configuration and initialization.

    def middleware(request):
        if not request.session.get('id'):
           return redirect('index')
        else:
            response=get_response(request)

        response = get_response(request)


        return response

    return middleware