from django.shortcuts import render
from django.views import View
from store.models.product import Product

class Cart(View):
    def get(self,request):
        if not request.session.get('cart'):
            request.session['cart'] = {}
        ids=list(request.session.get('cart').keys())
        products=Product.get_product(ids)
        print(products)
        return render(request,'cart.html',{'products':products})