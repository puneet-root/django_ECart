from django.views import View
from django.shortcuts import render

from store.models.orders import Order


class CustomerOrder(View):
    def get(self, request):
        customer = request.session.get('id')
        order = Order.get_order_of_customer(customer)

        return render(request, 'order.html', {'orders': order})
