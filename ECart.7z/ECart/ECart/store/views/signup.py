from django.views import View
from django.contrib import messages
from django.shortcuts import redirect, render
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postdata = request.POST
        signup_username = postdata.get('signup_username')
        first_name = postdata.get('firstname')
        last_name = postdata.get('lastname')
        phone = postdata.get('phone')
        email = postdata.get('email')
        password = postdata.get('password')
        conformpassword = postdata.get('conformpassword')

        customer = Customer(username=signup_username, firstname=first_name, lastname=last_name,
                            phone=phone, email=email, password=password)

        values = {'signup_username': signup_username, 'firstname': first_name, 'lastname': last_name,
                  'phone': phone, 'email': email}

        errormsg = self.validation(customer, conformpassword)  # //-- VALIDATING THE CUSTOMER DATA----//
        if not errormsg:
            customer.password = make_password(
                customer.password)  # //-------------- PASSWORD HASHING OF THE CUSTOMER DATA---//
            customer.save()  # //------ SAVING THE CUSTOMER DATA INTO THE DATABASE---//
            messages.success(request,'Successfully Signup')
            return redirect('index')
        else:
            signupdata = {'values': values, 'error': errormsg}
            return render(request, 'signup.html',
                          signupdata)  # ------------RETURNING THE ERROR MESSAGE AND PREVIOUS VALUES-

    def validation(self, customr, cnfrmpass):
        # ----------------------------------VALIDATION OF USER DATA---------------------
        errormsg = None
        conformpassword = cnfrmpass

        if not customr.firstname or len(customr.firstname) < 3:
            errormsg = 'First Name should be at least 3 characters long'
        elif customr.signup_username():
            errormsg = 'Username already exists'
        elif len(customr.username) > 10:
            errormsg = "Username have 10 characters maximum"
        elif not customr.lastname or len(customr.lastname) < 3:
            errormsg = 'Last Name should be at least 3 characters long'
        elif not customr.phone or len(customr.phone) < 10:
            errormsg = 'Invalid Phone Number'
        elif not customr.password or len(customr.password) < 6:
            errormsg = 'Password required has minimum 6 characters'
        elif customr.password != conformpassword:
            errormsg = "Password didn't matched"
        elif customr.checkemail():
            errormsg = 'Email already exist'
        return errormsg
