from django.views import View
from django.shortcuts import redirect,HttpResponse
from django.contrib.auth.hashers import check_password
from store.models.customer import Customer
from django.contrib import messages


class Login(View):
    errormsg=None
    def get(self, request):
        return redirect('index')

    def post(self, request):
        postdata = request.POST
        loginusername = postdata.get('loginusername')
        loginpassword = postdata.get('loginpassword')
        customer = Customer.checkuser(loginusername)  # //-----------CHECKING THE USERNAME--------////////
        if customer:
            loginpassword = check_password(loginpassword, customer.password)  # //---CHECKING THE PASSWORD HASH----//
            if loginpassword:
               request.session['username'] = customer.username
               request.session['id']=customer.id

               messages.success(request,'Login Successfully')

            else:
                messages.error(request,'Invalid Password')
        else:
            messages.error(request,'Invalid Username')

        return redirect('index')
