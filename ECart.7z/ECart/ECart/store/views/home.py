from django.shortcuts import render, redirect
from store.models.product import Product
from store.models.category import Category
from django.views import View
# Create your views here.

class Index(View):
    def get(self,request):
        category = Category.objects.all()
        categoryid = request.GET.get('category')
        if categoryid:
            products = Product.get_category_id(categoryid)
        else:
            products = Product.objects.all()
        data = {'category': category, 'products': products}

        return render(request, 'index.html', data)
    def post(self,request):
        product=request.POST.get('product_id')
        cart=request.session.get('cart')

        remove=request.POST.get('remove')
        print('value of the remove is ',remove)
        if cart:
            quantity=cart.get(product)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(product)
                    else:
                        cart[product]=quantity-1
                else:
                    cart[product]=quantity+1
            else:
                cart[product]=1
        else:
            cart={}
            cart[product]=1


        request.session['cart']=cart
        print(request.session['cart'])
        return redirect('index')

def logout(request):
    request.session.clear()
    return redirect('index')


def cart(request):
    return render(request,'cart.html')