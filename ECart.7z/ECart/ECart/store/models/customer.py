from django.db import models
class Customer(models.Model):
    username=models.CharField(max_length=10)
    firstname=models.CharField(max_length=30)
    lastname=models.CharField(max_length=30)
    email=models.EmailField()
    phone=models.CharField(max_length=12,default=0)
    password=models.CharField(max_length=500)

    def checkemail(self):
        if Customer.objects.filter(email=self.email):
            return True
        else:
            return False
    def signup_username(self):
        if Customer.objects.filter(username=self.username):
            return True
        else:
            return False

    def checkuser(username):
        try:
            return Customer.objects.get(username=username)
        except:
            return  False
