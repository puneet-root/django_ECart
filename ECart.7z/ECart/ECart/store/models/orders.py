from .product import Product
from django.db import models
from .customer import Customer
import datetime

class Order(models.Model):
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    quantity=models.IntegerField()
    price=models.IntegerField()
    address=models.CharField(max_length=90,default='')
    phone=models.CharField(max_length=12,default='')
    date=models.DateTimeField(default=datetime.datetime.now)
    status=models.BooleanField(default=False)

    @staticmethod
    def get_order_of_customer(customer):
        return Order.objects.filter(customer=customer).order_by('-date')