from django import template

register = template.Library()


@register.filter(name='product_cart')
def prodct_cart(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == int(product.id):
            return True
    return False


@register.filter(name='cart_items')  # -----------to find the quantity of the specific item
def cart_items(product, cart):
    keys = cart.keys()
    for id in keys:
        if int(id) == int(product.id):
            return cart.get(id)
    return 0


@register.filter(name='quantity_price')  # ----------for the sum of the price of the specific quantity
def quantity_price(product, cart):
    price = product.price * cart_items(product, cart)
    return price


@register.filter(name="total_price")
def total_price(products, cart):
    price = 0
    for product in products:
        price += quantity_price(product, cart)
    return price


@register.filter(name="multiply")  # mulitpy the price with quantiy of the order in the order template
def multiply(number, number1):
    return number * number1
