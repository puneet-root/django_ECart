from django import template
register=template.Library()
@register.filter(name='currency')
def currency_symbol(number):
    return "₹ "+str(number)